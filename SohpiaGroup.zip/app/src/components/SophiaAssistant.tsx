import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Bot, User, Sparkles, MessageCircle, BookOpen, Building2, Scale, Calculator } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

interface QuickTopic {
  id: string;
  icon: React.ElementType;
  label: string;
  question: string;
}

interface SophiaAssistantProps {
  onClose: () => void;
}

const WHATSAPP_URL = 'https://wa.me/573218530960';

// Temas rápidos para consulta
const quickTopics: QuickTopic[] = [
  { id: 'servicios', icon: Building2, label: 'Nuestros Servicios', question: '¿Qué servicios ofrece Sophia Group?' },
  { id: 'ley675', icon: Scale, label: 'Ley 675 de 2001', question: '¿Qué es la Ley 675 de 2001?' },
  { id: 'precios', icon: Calculator, label: 'Precios', question: '¿Cuánto cuesta la administración?' },
  { id: 'contacto', icon: MessageCircle, label: 'Contacto', question: '¿Cómo puedo contactarlos?' },
];

// Información sobre Propiedad Horizontal
const phInfo = {
  'que es ph': `**¿Qué es la Propiedad Horizontal?**

La Propiedad Horizontal es un régimen de propiedad donde:
• Cada propietario tiene dominio exclusivo sobre su unidad privada (apartamento, casa, local)
• Existe propiedad común sobre áreas compartidas (ascensores, zonas verdes, garajes comunes, salones sociales)
• Se rige por la Ley 675 de 2001 en Colombia

Este régimen requiere una administración profesional para gestionar los recursos comunes y mantener la convivencia.`,

  'ley 675': `**Ley 675 de 2001**

Es la norma que regula la Propiedad Horizontal en Colombia:

📋 **Aspectos principales:**
• Establece la figura del Administrador
• Define las obligaciones de copropietarios
• Regula las Asambleas y sus decisiones
• Establece el régimen de cuotas de administración
• Define las sanciones por incumplimiento

En Sophia Group garantizamos cumplimiento total de esta ley.`,

  'asamblea': `**Asambleas de Propiedad Horizontal**

Las asambleas son la máxima autoridad de la PH:

📅 **Tipos:**
• **Ordinarias:** Realizadas anualmente para aprobar presupuesto
• **Extraordinarias:** Convocadas para decisiones urgentes

✅ **Quórum:**
• 1ª convocatoria: 60% de coeficientes
• 2ª convocatoria: 30% de coeficientes

Nosotros gestionamos todo el proceso de sus asambleas.`,

  'coeficiente': `**Coeficiente de Copropiedad**

Es el porcentaje que determina:
• El valor de las cuotas de administración
• El peso del voto en asambleas
• La responsabilidad en gastos comunes

📊 Se calcula según:
• Metraje de la unidad privada
• Ubicación dentro del edificio
• Uso de zonas comunes

Garantizamos cálculos precisos y transparentes.`,

  'cuota': `**Cuotas de Administración**

Son los pagos mensuales que cada propietario debe realizar:

💰 **Cobertura:**
• Servicios públicos comunes
• Mantenimiento de áreas
• Nómina del personal
• Seguros
• Reservas para reparaciones

En Sophia Group elaboramos presupuestos claros y justos.`,

  'pqrs': `**PQRS en Propiedad Horizontal**

Sistema de Peticiones, Quejas, Reclamos y Sugerencias:

📝 **Gestión profesional de:**
• Peticiones de información
• Quejas por incumplimientos
• Reclamos de servicios
• Sugerencias de mejora

Ofrecemos atención oportuna y trazabilidad completa.`,

  'mantenimiento': `**Mantenimiento en PH**

Es fundamental para preservar el patrimonio:

🔧 **Tipos:**
• **Preventivo:** Programado periódicamente
• **Correctivo:** Reparaciones urgentes
• **Predictivo:** Basado en análisis de estado

Nuestra gestión incluye planificación anual y proveedores calificados.`,
};

// Base de conocimiento completa de Sophia Group
const sophiaKnowledge: Record<string, string> = {
  // Saludos
  'hola': `¡Hola! 👋 Bienvenido a Sophia Group.

Soy **Sophia**, tu asistente virtual especializada en Propiedad Horizontal. Estoy aquí para ayudarte con:

• Información sobre nuestros servicios
• Consultas sobre Propiedad Horizontal
• Dudas sobre la Ley 675 de 2001
• Cotizaciones y contacto

¿En qué puedo asistirte hoy?`,

  'buenos dias': `¡Buenos días! ☀️ Soy Sophia, asistente virtual de Sophia Group.

Estoy lista para ayudarte con información sobre administración de Propiedad Horizontal. ¿Qué necesitas saber?`,

  'buenas tardes': `¡Buenas tardes! 🌤️ Bienvenido a Sophia Group.

Soy Sophia, tu asistente virtual. ¿En qué puedo ayudarte sobre nuestros servicios de administración de PH?`,

  'buenas noches': `¡Buenas noches! 🌙 Gracias por contactar a Sophia Group.

Soy Sophia, asistente virtual. Aunque sea tarde, estoy aquí para responder tus preguntas. ¿Qué necesitas?`,

  // Servicios principales
  'servicios': `**Nuestros Servicios** 🏢

En Sophia Group ofrecemos soluciones integrales:

**1. ADMINISTRACIÓN INTEGRAL**
• Planeación estratégica anual
• Organización de asambleas
• Elaboración de actas
• Gestión de proveedores
• Atención PQRS
• Informes mensuales

**2. ASESORÍA CONTABLE/FINANCIERA**
• Estados financieros mensuales
• Presupuestos anuales
• Gestión de cartera
• Cumplimiento NIIF

**3. ASESORÍA JURÍDICA**
• Cobro prejurídico
• Habeas Data
• Reglamentos de convivencia
• Ley 675 de 2001

**4. AUDITORÍA Y REVISORÍA**
• Auditoría externa
• Revisoría fiscal

¿Te gustaría más detalles de algún servicio?`,

  'administracion': `**Administración Integral** 📋

Nuestro servicio principal incluye:

✅ **Planeación Estratégica**
• Presupuesto anual detallado
• Plan de mantenimiento
• Proyección de gastos

✅ **Asambleas**
• Convocatorias reglamentarias
• Preparación de documentación
• Actas digitales con IA

✅ **Gestión Diaria**
• Proveedores y contratos
• PQRS con seguimiento
• Informes mensuales claros

✅ **Tecnología SOFIA**
• Portal de transparencia 24/7
• Pasarela de pagos
• Biblioteca legal con IA

Todo respaldado por +10 años de experiencia.`,

  'contable': `**Asesoría Contable/Financiera** 💰

Gestión financiera profesional:

📊 **Estados Financieros**
• Mensuales detallados
• Cumplimiento NIIF
• Conciliaciones bancarias

📈 **Presupuestos**
• Elaboración anual
• Seguimiento mensual
• Variaciones explicadas

💳 **Cartera**
• Gestión de cobranza
• Estados de cuenta
• Acuerdos de pago

Garantizamos transparencia total en cada peso administrado.`,

  'juridica': `**Asesoría Jurídica** ⚖️

Protección legal integral:

📝 **Cobro de Cartera**
• Prejurídico profesional
• Requerimientos formales
• Reporte a centrales (si aplica)

📜 **Documentación**
• Reglamentos de propiedad horizontal
• Reglamentos de convivencia
• Manual de convivencia

🔒 **Protección de Datos**
• Cumplimiento Habeas Data
• Políticas de privacidad
• Manejo seguro de información

⚖️ **Ley 675 de 2001**
• Asesoría especializada
• Actualización normativa
• Mediación de conflictos`,

  'auditoria': `**Auditoría y Revisoría** 🔍

Control independiente de la gestión:

📋 **Auditoría Externa**
• Revisión de estados financieros
• Verificación de procesos
• Informes de hallazgos

📊 **Revisoría Fiscal**
• Vigilancia de la administración
• Revisión de legalidad
• Informes a asambleas

✅ **Beneficios:**
• Mayor confianza de copropietarios
• Detección temprana de problemas
• Cumplimiento normativo verificado`,

  // Bonos/Plus
  'portal': `**Portal Web de Transparencia** 🌐

Acceso 24/7 a toda la información:

📄 **Documentos Disponibles**
• Estados financieros actualizados
• Actas de asambleas
• Certificados de pago
• Documentos de la PH

🔔 **Notificaciones**
• Avisos de asambleas
• Recordatorios de pago
• Comunicados importantes

📱 **Multi-dispositivo**
• Acceso desde celular, tablet o PC
• Interfaz intuitiva
• Sin costo adicional

Incluido en todos nuestros planes.`,

  'pagos': `**Pasarela de Pagos en Línea** 💳

Paga tus cuotas desde cualquier lugar:

💳 **Métodos Aceptados**
• Tarjetas débito/crédito
• Transferencias bancarias
• PSE
• Efecty (convenio)

📄 **Comprobantes**
• Generación automática
• Envío por email
• Historial de pagos

⏰ **Recordatorios**
• Notificaciones antes del vencimiento
• Evita moras
• Mantén tu paz y salvo

Comodidad y seguridad garantizadas.`,

  'biblioteca': `**Biblioteca Inteligente con IA** 📚

Consulta la normatividad fácilmente:

📖 **Contenido**
• Ley 675 de 2001 actualizada
• Decretos reglamentarios
• Jurisprudencia relevante
• Circulares del Ministerio

🤖 **Asistencia IA**
• Búsqueda inteligente
• Respuestas a preguntas específicas
• Interpretación de normas

💡 **Beneficio:** Entiende tus derechos y deberes como copropietario.`,

  'sofia pack': `**SOFIA PACK** 🤖

Nuestra suite de asistentes de IA:

📝 **Asistente de Actas**
• Generación automática
• Formato profesional
• Minutas en tiempo real

⚖️ **Asistente Jurídico**
• Respuestas sobre normativa PH
• Consultas 24/7
• Información actualizada

💰 **Asistente de Presupuesto**
• Análisis predictivo
• Proyecciones de gastos
• Recomendaciones de ahorro

Tecnología exclusiva de Sophia Group.`,

  // Información de contacto
  'precio': `**Inversión en su PH** 💰

El valor de nuestros servicios depende de:

📊 **Factores:**
• Número de unidades
• Metraje total
• Áreas comunes
• Ubicación
• Servicios requeridos

✅ **Incluye:**
• Honorarios administrativos
• Póliza de cumplimiento
• Portal de transparencia
• Pasarela de pagos
• Biblioteca legal IA

📞 **Solicita tu cotización personalizada:**
WhatsApp: +57 321 853 0960
Email: atencionalcliente@sophiagrouph.com`,

  'costo': `**Inversión en su PH** 💰

El valor de nuestros servicios depende de:

📊 **Factores:**
• Número de unidades
• Metraje total
• Áreas comunes
• Ubicación
• Servicios requeridos

✅ **Incluye:**
• Honorarios administrativos
• Póliza de cumplimiento
• Portal de transparencia
• Pasarela de pagos
• Biblioteca legal IA

📞 **Solicita tu cotización personalizada:**
WhatsApp: +57 321 853 0960
Email: atencionalcliente@sophiagrouph.com`,

  'contacto': `**Contáctanos** 📞

Estamos listos para atenderte:

📱 **WhatsApp:** +57 321 853 0960
📧 **Email:** atencionalcliente@sophiagrouph.com
🌐 **Web:** www.sophiagrouph.com
📍 **Ubicación:** Colombia

⏰ **Horario de atención:**
Lunes a Viernes: 8:00 am - 6:00 pm
Sábados: 9:00 am - 1:00 pm

Escríbenos y te responderemos en menos de 24 horas.`,

  'telefono': `**Nuestros Teléfonos** 📱

📞 **Línea principal:** +57 321 853 0960

💬 **WhatsApp:** +57 321 853 0960
(Haz clic para chatear directamente)

✅ Respuesta garantizada en menos de 24 horas.

También puedes escribirnos a:
📧 atencionalcliente@sophiagrouph.com`,

  'email': `**Correo Electrónico** 📧

✉️ **Email principal:**
atencionalcliente@sophiagrouph.com

✅ Te responderemos en menos de 24 horas.

📱 Para respuesta inmediata, escríbenos por WhatsApp:
+57 321 853 0960`,

  // Equipo
  'equipo': `**Nuestro Equipo** 👥

Profesionales certificados:

👨‍💼 **Adolfo Ardila** - Director Ejecutivo
Experto en administración de PH con +15 años de experiencia.

👩‍💼 **Angela Cano** - Directora Financiera
Especialista en gestión contable y NIIF.

👨‍⚖️ **Camilo Garcés** - Director Jurídico
Abogado especializado en derecho inmobiliario.

👨‍💻 **Juan C. Cardona** - Director de Operaciones
Experto en tecnología aplicada a la administración.

Todos con certificaciones y capacitación continua.`,

  // Tecnología
  'ia': `**Inteligencia Artificial en Sophia Group** 🤖

Integramos IA en todos nuestros procesos:

🤖 **Aplicaciones:**
• Asistente virtual (yo)
• Generación de actas
• Análisis predictivo financiero
• Biblioteca legal inteligente
• Automatización de reportes

💡 **Beneficios:**
• Mayor eficiencia
• Menos errores humanos
• Respuestas más rápidas
• Análisis de datos avanzados

Tecnología de punta al servicio de su PH.`,

  'transparencia': `**Transparencia Total** 🔍

En Sophia Group creemos en la información clara:

📊 **Acceso 24/7:**
• Estados financieros actualizados
• Historial de actas
• Documentos de la PH
• Trazabilidad de pagos

📱 **Múltiples canales:**
• Portal web
• WhatsApp
• Email
• Llamadas

💬 **Comunicación constante:**
• Informes mensuales
• Notificaciones importantes
• Atención a PQRS

La transparencia que los copropietarios exigen.`,

  // Garantías
  'garantia': `**Nuestras Garantías** ✅

Trabajamos con los más altos estándares:

🎓 **Equipo Certificado**
Profesionales con certificaciones y capacitación continua.

📋 **Procesos Estandarizados**
Metodologías documentadas y mejora continua.

🛡️ **Póliza de Cumplimiento**
Garantía de cumplimiento de obligaciones contractuales.

📈 **+10 años de experiencia**
+100 PH administradas con éxito.

Tu propiedad está en buenas manos.`,

  'experiencia': `**Nuestra Experiencia** 🏆

+10 años transformando la administración de PH:

📊 **Números que respaldan:**
• +100 PH administradas
• +5,000 copropietarios atendidos
• 98% de satisfacción del cliente
• 100% de cumplimiento normativo

🏅 **Reconocimientos:**
• Equipo certificado
• Procesos estandarizados
• Tecnología propietaria (SOFIA)
• Póliza de cumplimiento

Confía en los expertos.`,
};

// Función mejorada para encontrar respuestas
function generateResponse(input: string): { type: 'sophia' | 'ph' | 'default'; content: string } {
  const lowerInput = input.toLowerCase().trim();
  
  // Saludos
  if (/^(hola|buenos dias|buenas tardes|buenas noches|hey|saludos|hi|hello)$/i.test(lowerInput)) {
    return { type: 'sophia', content: sophiaKnowledge['hola'] };
  }
  
  // Buscar en conocimiento de Sophia Group
  const sophiaKeywords = [
    { keys: ['servicio', 'ofrecen', 'hacen', 'que hacen'], response: 'servicios' },
    { keys: ['administracion integral', 'administración'], response: 'administracion' },
    { keys: ['contable', 'contabilidad', 'financiera', 'finanzas', 'estados financieros'], response: 'contable' },
    { keys: ['juridica', 'jurídica', 'legal', 'abogado', 'ley'], response: 'juridica' },
    { keys: ['auditoria', 'auditoría', 'revisoria', 'revisoría'], response: 'auditoria' },
    { keys: ['portal', 'transparencia', 'web'], response: 'portal' },
    { keys: ['pagos', 'pago', 'pagar', 'pasarela'], response: 'pagos' },
    { keys: ['biblioteca', 'normas', 'normatividad', 'leyes'], response: 'biblioteca' },
    { keys: ['sofia pack', 'sofia', 'ia', 'inteligencia artificial'], response: 'sofia pack' },
    { keys: ['precio', 'precios', 'costo', 'costos', 'cuanto cuesta', 'cuánto cuesta', 'valor', 'tarifa'], response: 'precio' },
    { keys: ['contacto', 'contactar', 'escribir', 'hablar'], response: 'contacto' },
    { keys: ['telefono', 'teléfono', 'whatsapp', 'llamar'], response: 'telefono' },
    { keys: ['email', 'correo', 'e-mail'], response: 'email' },
    { keys: ['equipo', 'directores', 'quienes son', 'quiénes son'], response: 'equipo' },
    { keys: ['ia', 'inteligencia artificial', 'tecnologia', 'tecnología'], response: 'ia' },
    { keys: ['garantia', 'garantías', 'certificado'], response: 'garantia' },
    { keys: ['experiencia', 'años', 'trayectoria'], response: 'experiencia' },
  ];
  
  for (const item of sophiaKeywords) {
    if (item.keys.some(key => lowerInput.includes(key))) {
      return { type: 'sophia', content: sophiaKnowledge[item.response] };
    }
  }
  
  // Buscar en información de PH
  const phKeywords = [
    { keys: ['que es ph', 'qué es ph', 'propiedad horizontal', 'que es una ph'], response: 'que es ph' },
    { keys: ['ley 675', 'ley 675 de 2001'], response: 'ley 675' },
    { keys: ['asamblea', 'asambleas'], response: 'asamblea' },
    { keys: ['coeficiente', 'coeficientes', 'copropiedad'], response: 'coeficiente' },
    { keys: ['cuota', 'cuotas', 'administración'], response: 'cuota' },
    { keys: ['pqrs', 'peticiones', 'quejas', 'reclamos'], response: 'pqrs' },
    { keys: ['mantenimiento', 'mantener', 'reparaciones'], response: 'mantenimiento' },
  ];
  
  for (const item of phKeywords) {
    if (item.keys.some(key => lowerInput.includes(key))) {
      return { type: 'ph', content: phInfo[item.response as keyof typeof phInfo] };
    }
  }
  
  // Respuestas a despedidas
  if (/^(gracias|muchas gracias|te agradezco|agradecido)$/i.test(lowerInput)) {
    return { type: 'sophia', content: '¡De nada! 😊 Estoy aquí para lo que necesites. ¿Hay algo más en lo que pueda ayudarte?' };
  }
  
  if (/^(adios|adiós|hasta luego|chao|bye|nos vemos)$/i.test(lowerInput)) {
    return { type: 'sophia', content: '¡Hasta luego! 👋 Gracias por contactar a Sophia Group. Que tengas un excelente día. Recuerda que estoy aquí cuando me necesites.' };
  }
  
  if (/^(ayuda|help|auxilio|no se|no sé)$/i.test(lowerInput)) {
    return { type: 'sophia', content: `¡Claro que sí! 💪 Puedo ayudarte con:

🏢 **Sobre Sophia Group:**
• Nuestros servicios de administración
• Precios y cotizaciones
• Contacto y ubicación
• Nuestro equipo

📚 **Sobre Propiedad Horizontal:**
• ¿Qué es una PH?
• Ley 675 de 2001
• Asambleas y coeficientes
• Cuotas y mantenimiento

¿Sobre cuál tema te gustaría información?` };
  }
  
  // Respuesta por defecto
  return { 
    type: 'default', 
    content: `Entiendo tu consulta. Permíteme ayudarte:

🔍 **Puedo asistirte con:**
• Información sobre nuestros servicios
• Dudas sobre Propiedad Horizontal
• Cotizaciones personalizadas
• Contacto directo

📞 **Para atención inmediata:**
WhatsApp: +57 321 853 0960

¿Te gustaría que te explique algo específico sobre nuestros servicios o sobre Propiedad Horizontal?` 
  };
}

export default function SophiaAssistant({ onClose }: SophiaAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: sophiaKnowledge['hola'],
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showInfoBox, setShowInfoBox] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSend = async (text?: string) => {
    const messageText = text || inputValue;
    if (!messageText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageText.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);
    setShowInfoBox(false);

    setTimeout(() => {
      const response = generateResponse(userMessage.content);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: response.content,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 800 + Math.random() * 600);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleTopicClick = (topic: QuickTopic) => {
    handleSend(topic.question);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: 20 }}
      transition={{ duration: 0.3 }}
      className="fixed bottom-24 right-6 z-50 w-[420px] max-w-[calc(100vw-48px)] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1e3a5f] to-[#0c4a6e] p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Sparkles size={20} className="text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Sophia Assistant</h3>
            <p className="text-xs text-white/70">Experta en Propiedad Horizontal</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center text-white/70 hover:bg-white/20 hover:text-white transition-colors"
        >
          <X size={18} />
        </button>
      </div>

      {/* Messages */}
      <div className="h-[380px] overflow-y-auto p-4 bg-slate-50">
        <div className="space-y-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${
                message.type === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  message.type === 'user'
                    ? 'bg-[#0ea5e9]'
                    : 'bg-gradient-to-r from-[#1e3a5f] to-[#0c4a6e]'
                }`}
              >
                {message.type === 'user' ? (
                  <User size={16} className="text-white" />
                ) : (
                  <Bot size={16} className="text-white" />
                )}
              </div>
              <div
                className={`max-w-[80%] p-3 rounded-2xl text-sm whitespace-pre-line ${
                  message.type === 'user'
                    ? 'bg-[#0ea5e9] text-white rounded-tr-sm'
                    : 'bg-white text-slate-700 shadow-sm border border-slate-100 rounded-tl-sm'
                }`}
                dangerouslySetInnerHTML={{
                  __html: message.content
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/📋|📊|💰|⚖️|🔍|✅|📱|💬|🏢|👥|🤖|📧|📞|📍|💳|📄|📖|📅|📈|🔔|⏰|💡|🛡️|🎓|📋|🏆|👨‍💼|👩‍💼|👨‍⚖️|👨‍💻|☀️|🌤️|🌙|👋|😊|💪/g, match => match)
                }}
              />
            </motion.div>
          ))}
          
          {/* Info Box - Temas de PH */}
          <AnimatePresence>
            {showInfoBox && messages.length === 1 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-gradient-to-br from-[#f0f9ff] to-[#e0f2fe] rounded-xl p-4 border border-[#0ea5e9]/20"
              >
                <div className="flex items-center gap-2 mb-3">
                  <BookOpen size={18} className="text-[#0ea5e9]" />
                  <span className="font-semibold text-[#1e3a5f] text-sm">Temas de Propiedad Horizontal</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: '¿Qué es una PH?', query: '¿Qué es la propiedad horizontal?' },
                    { label: 'Ley 675', query: '¿Qué es la Ley 675 de 2001?' },
                    { label: 'Asambleas', query: '¿Cómo funcionan las asambleas?' },
                    { label: 'Cuotas', query: '¿Qué son las cuotas de administración?' },
                  ].map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSend(item.query)}
                      className="text-left px-3 py-2 bg-white rounded-lg text-xs text-slate-600 hover:bg-[#0ea5e9] hover:text-white transition-colors"
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#1e3a5f] to-[#0c4a6e] flex items-center justify-center">
                <Bot size={16} className="text-white" />
              </div>
              <div className="bg-white p-3 rounded-2xl rounded-tl-sm shadow-sm border border-slate-100">
                <div className="flex gap-1">
                  <motion.div
                    animate={{ y: [0, -4, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, delay: 0 }}
                    className="w-2 h-2 bg-slate-400 rounded-full"
                  />
                  <motion.div
                    animate={{ y: [0, -4, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, delay: 0.15 }}
                    className="w-2 h-2 bg-slate-400 rounded-full"
                  />
                  <motion.div
                    animate={{ y: [0, -4, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, delay: 0.3 }}
                    className="w-2 h-2 bg-slate-400 rounded-full"
                  />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Topics */}
      <div className="px-4 py-3 bg-white border-t border-slate-100">
        <p className="text-xs text-slate-400 mb-2">Temas populares:</p>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {quickTopics.map((topic) => (
            <button
              key={topic.id}
              onClick={() => handleTopicClick(topic)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-[#0ea5e9] hover:text-white rounded-full text-xs text-slate-600 transition-colors whitespace-nowrap"
            >
              <topic.icon size={12} />
              {topic.label}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t border-slate-100">
        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Escribe tu pregunta sobre PH..."
            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0ea5e9] focus:border-transparent transition-all"
          />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleSend()}
            disabled={!inputValue.trim() || isTyping}
            className="w-12 h-12 bg-gradient-to-r from-[#1e3a5f] to-[#0c4a6e] rounded-xl flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-shadow"
          >
            <Send size={18} />
          </motion.button>
        </div>
        <div className="flex items-center justify-between mt-2">
          <p className="text-xs text-slate-400">
            Sophia responde sobre PH y servicios de Sophia Group
          </p>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-[#0ea5e9] hover:underline"
          >
            ¿Necesitas un humano? →
          </a>
        </div>
      </div>
    </motion.div>
  );
}
